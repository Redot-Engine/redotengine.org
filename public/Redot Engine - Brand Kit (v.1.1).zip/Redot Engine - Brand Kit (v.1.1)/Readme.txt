-----------

Redot Engine Logo
Copyright (c) 2024 Asrorul Irsyad
This work is licensed under the Creative Commons Attribution 4.0 International
license (CC BY 4.0 International): https://creativecommons.org/licenses/by/4.0/

If you have any questions about the use of Redot Engine logo in ways not described in the license, please contact the Redot Engine core team.

-----------

Redot Logos are made using Inkscape.

-----------

